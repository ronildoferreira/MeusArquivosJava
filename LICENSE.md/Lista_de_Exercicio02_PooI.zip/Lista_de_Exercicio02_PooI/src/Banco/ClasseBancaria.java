package Banco;

import java.util.Scanner;

public class ClasseBancaria {
	String nome;
    Integer numero;
    Double saldo;
        
    Scanner in = new Scanner (System.in);

    public ClasseBancaria(String nome, Integer numero, Double saldo) {
        this.nome = nome;
        this.numero = numero;
        this.saldo = saldo;
    }

    public ClasseBancaria() {
    }
    
    
    public void deposito(double valor){
        saldo = saldo +valor; 
        System.out.println("Deposito Realizado");
    }
    void extrado(){
        System.out.println("Saldo: "+saldo);
    }
    void transferencia (ClasseBancaria destino, double valor){
        saldo = saldo+valor;
        destino.saldo -= valor;
        System.out.println("Transferencia Realizada!");
    }
    void sacar (double valor){
   
            saldo -= valor;
            System.out.println("Saque Realizado");
        
    
}
}
