package Banco;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Banco {

	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		ClasseBancaria conta01 = new ClasseBancaria("Antonio", 123, 500d);
		ClasseBancaria conta02 = new ClasseBancaria("Pedro", 1, 567d);
		ClasseBancaria conta03 = new ClasseBancaria();
		int op = 0;
		ArrayList<ClasseBancaria> bd = new ArrayList();
		bd.add(conta01);
		bd.add(conta02);

		do {

			System.out.printf("Digite:\n1-Saldo\n2-Deposito\n3-Transferencia\n4-Sacar\n0-Sair\nOp��o:");
			op = in.nextInt();
			switch (op) {
			case 1:
			System.out.println("Digite o numero da conta");
				Integer nc = in.nextInt();
				System.out.println("Digite um valor");
			
			for (ClasseBancaria classe : bd) {
			if (classe.numero.equals(nc)) {
			classe.extrado();
					}
				}

			break;
			case 2:
			System.out.println("Digite o numero da conta");
			nc = in.nextInt();
				System.out.println("Digite um valor");
			for (ClasseBancaria classe : bd) {
				if (classe.numero.equals(nc)) {
						System.out.println("Digite o valor");
			double interno = in.nextDouble();
			classe.deposito(interno);

	}

}
	break;

		case 3:
		System.out.println("Digite o numero da sua conta");
		nc = in.nextInt();
		for (ClasseBancaria classe : bd) {
			if (classe.numero.equals(nc)) {
		System.out.println("Digite o numero da conta de destino");
		Integer des = in.nextInt();
		for (ClasseBancaria clas : bd) {
			if (clas.numero.equals(des)) {
		System.out.println("Digite o valor da transferencia: ");
			double val = in.nextDouble();
			if (val > classe.saldo) {
		System.out.println("Saldo insuficiente");
		} else {
		classe.transferencia(clas, val);

 }
}
}

}
}
		break;
		case 4:
		System.out.println("Digite o numero da sua conta");
		nc = in.nextInt();

		for (ClasseBancaria classe : bd) {
			if (classe.numero.equals(nc)) {
		System.out.println("Digite o valor");
			double val = in.nextDouble();
			if (classe.saldo < val) {
		System.out.println("Saldo insuficiente");
			} else {
		classe.sacar(val);
}
}

}
break;
}
} while (op != 0);

}

}
