package Estoque;

public class Em_Estoque {

	String nome;
	Integer QntAtual;
	Integer QntMinima;

	public Em_Estoque(String nome, Integer QntAtual, Integer QntMinima) {
        this.nome = nome;
        this.QntAtual = QntAtual;
        this.QntMinima = QntMinima;
    }

	void mudarNome(String nome) {
		this.nome = nome;

	}

	void mudarQtdMinima(int qtdMinima) {
		this.QntMinima = qtdMinima;

	}

	void repor(int qtd) {
		this.QntAtual += qtd;
	}

	void darBaixa(int qtd) {
		this.QntAtual -= qtd;

	}

	String mostra() {
		return "Nome" + nome + " Quantidade Atual" + QntAtual + "Quantidade Minima";
	}

	boolean precisaRepor() {
		if (QntMinima > QntAtual) {
			return true;
		} else {
			return false;
		}

	}

	public Em_Estoque() {
    }

	public static void main(String[] args) {

	}

}
