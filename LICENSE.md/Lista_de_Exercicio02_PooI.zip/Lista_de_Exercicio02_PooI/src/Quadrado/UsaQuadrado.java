package Quadrado;

public class UsaQuadrado {
    
	    
public static void main(String[] args) {
	       
	Quadrado q1 = new Quadrado (130);
	Quadrado q3 = new Quadrado (1220);
	Quadrado q2 = new Quadrado (90);
	       
	         
	System.out.println("Perimetro 1: "+"Area: "+q1.area()+" Perimetro: "+q1.perimetro());
	System.out.println("Perimetro 2: "+"Area: "+q2.area()+" Perimetro: "+q2.perimetro());
	System.out.println("Perimetro 3: "+"Area: "+q3.area()+" Perimetro: "+q3.perimetro());
 }
	    
}
