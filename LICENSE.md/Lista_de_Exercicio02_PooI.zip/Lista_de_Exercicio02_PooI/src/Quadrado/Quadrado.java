package Quadrado;

public class Quadrado {

	
	
	 float lado;

	    public Quadrado(float lado) {
	        this.lado = lado;
	    }
	   
	   
	   public float area(){
	       
	       
	       
	       return lado*lado;
	   }
	   public float perimetro(){
	       
	       return lado*4;
	   }
	   
	}
