package Lampada;

import java.util.Scanner;

public class Lampada {

	static boolean lampada;

	public static void main(String[] args) {

		int o = 0;
		Scanner op = new Scanner(System.in);

		do {
			System.out.println("1-Liga");
			System.out.println("2-Desliga");
			System.out.println("3-Observa");

			o = op.nextInt();
			if (o == 1) {
				lampada = ligar();
			}
			if (o == 2) {
				lampada = desliga();
			}
			if (o == 3) {
				System.out.println(oberva());
			}
		} while (o != 0);
		op.close();
	}

	public static boolean ligar() {
		return true;

	}

	public static boolean desliga() {
		return false;

	}

	public static String oberva() {
		if (lampada == true) {
			return "\n\nLigada!!!\n\n";
		} else {
			return "\n\nDesligada!!!\n\n";

		}
	}

}
